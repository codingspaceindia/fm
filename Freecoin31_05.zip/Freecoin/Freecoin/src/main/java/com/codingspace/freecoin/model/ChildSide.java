package com.codingspace.freecoin.model;

public enum ChildSide {
    LEFT, 
    RIGHT,
}
